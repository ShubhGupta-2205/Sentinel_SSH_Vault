#!/usr/bin/python3
"""Sentinel Vault v3: compatible AES-GCM object store; imported originals untouched."""
import os, json, base64, hashlib, secrets, uuid, time, datetime
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
HOME=Path.home(); ROOT=HOME/'.local/share/sentinel-ssh-vault'; OBJECTS=ROOT/'objects'; KEYFILE=ROOT/'key.json'; MANIFEST=ROOT/'manifest.enc'; INCIDENTS=ROOT/'unlock-incidents.jsonl'; ANALYZER=ROOT/'ssh-analysis.enc'; AUDIT=ROOT/'owner-audit.enc'; SETTINGS=ROOT/'settings.json'; MAGIC=b'SV02'
def b64(x): return base64.b64encode(x).decode('ascii')
def un64(x): return base64.b64decode(x.encode('ascii'))
def ensure_dirs():
 ROOT.mkdir(parents=True,exist_ok=True,mode=0o700); OBJECTS.mkdir(parents=True,exist_ok=True,mode=0o700); os.chmod(ROOT,0o700); os.chmod(OBJECTS,0o700)
def derive(password,salt): return hashlib.scrypt(password.encode(),salt=salt,n=2**15,r=8,p=1,dklen=32,maxmem=128*1024*1024)
def init_vault(password):
 ensure_dirs(); salt=secrets.token_bytes(16); nonce=secrets.token_bytes(12); master=secrets.token_bytes(32); wrapped=AESGCM(derive(password,salt)).encrypt(nonce,master,b'Sentinel Vault master key v2')
 write_atomic(KEYFILE,json.dumps({'version':2,'kdf':'scrypt-n32768-r8-p1','salt':b64(salt),'nonce':b64(nonce),'wrapped':b64(wrapped)}).encode(),0o600); save_manifest(master,[]); return master
def unlock(password):
 data=json.loads(KEYFILE.read_text()); return AESGCM(derive(password,un64(data['salt']))).decrypt(un64(data['nonce']),un64(data['wrapped']),b'Sentinel Vault master key v2')
def write_atomic(path,data,mode=0o600):
 path=Path(path); tmp=path.with_name(path.name+'.tmp'); tmp.write_bytes(data); os.chmod(tmp,mode); os.replace(tmp,path)
def save_manifest(master,items):
 nonce=secrets.token_bytes(12); payload=json.dumps({'version':3,'items':items},ensure_ascii=False,separators=(',',':')).encode(); write_atomic(MANIFEST,MAGIC+nonce+AESGCM(master).encrypt(nonce,payload,b'Sentinel Vault manifest v2'))
def load_manifest(master):
 if not MANIFEST.exists():return []
 b=MANIFEST.read_bytes(); payload=AESGCM(master).decrypt(b[4:16],b[16:],b'Sentinel Vault manifest v2'); return json.loads(payload.decode())['items']
def encrypt_file(master,path,relative=None):
 raw=Path(path).read_bytes(); nonce=secrets.token_bytes(12); ident=uuid.uuid4().hex; blob=MAGIC+nonce+AESGCM(master).encrypt(nonce,raw,b'Sentinel Vault file v2'); write_atomic(OBJECTS/ident,blob); return {'id':ident,'name':Path(path).name,'path':relative or Path(path).name,'size':len(raw),'added':int(time.time())}
def decrypt_file(master,item):
 blob=(OBJECTS/item['id']).read_bytes(); return AESGCM(master).decrypt(blob[4:16],blob[16:],b'Sentinel Vault file v2')
def change_password(master,new_password):
 salt=secrets.token_bytes(16); nonce=secrets.token_bytes(12); wrapped=AESGCM(derive(new_password,salt)).encrypt(nonce,master,b'Sentinel Vault master key v2'); write_atomic(KEYFILE,json.dumps({'version':2,'kdf':'scrypt-n32768-r8-p1','salt':b64(salt),'nonce':b64(nonce),'wrapped':b64(wrapped)}).encode())

def load_analyzer_events(master):
 if not ANALYZER.exists(): return []
 blob=ANALYZER.read_bytes()
 if not blob.startswith(b'SA01') or len(blob)<16: return []
 nonce=blob[4:16]
 payload=AESGCM(master).decrypt(nonce,blob[16:],b'Sentinel SSH analyzer history v1')
 return json.loads(payload.decode()).get('events',[])
def save_analyzer_events(master,events):
 ensure_dirs(); nonce=secrets.token_bytes(12); payload=json.dumps({'version':1,'events':events[-5000:]},ensure_ascii=False,separators=(',',':')).encode()
 write_atomic(ANALYZER,b'SA01'+nonce+AESGCM(master).encrypt(nonce,payload,b'Sentinel SSH analyzer history v1'),0o600)


def load_audit(master):
 if not AUDIT.exists():return []
 blob=AUDIT.read_bytes()
 if not blob.startswith(b'SAU1') or len(blob)<16:return []
 nonce=blob[4:16];payload=AESGCM(master).decrypt(nonce,blob[16:],b'Sentinel owner audit v1')
 return json.loads(payload.decode()).get('events',[])
def save_audit(master,events):
 ensure_dirs();nonce=secrets.token_bytes(12);payload=json.dumps({'version':1,'events':events[-2000:]},ensure_ascii=False,separators=(',',':')).encode();write_atomic(AUDIT,b'SAU1'+nonce+AESGCM(master).encrypt(nonce,payload,b'Sentinel owner audit v1'),0o600)
def audit(master,action,detail=''):
 try:events=load_audit(master)
 except Exception:events=[]
 now=time.time();local=datetime.datetime.fromtimestamp(now).astimezone()
 events.append({'id':uuid.uuid4().hex,'epoch':now,'timestamp':local.isoformat(timespec='seconds'),'action':str(action)[:80],'detail':str(detail)[:240]})
 save_audit(master,events)
 return events[-1]

def _log_unlock_event(outcome):
 ensure_dirs(); now=time.time(); local=datetime.datetime.fromtimestamp(now).astimezone()
 entry={'id':uuid.uuid4().hex,'timestamp':local.isoformat(timespec='seconds'),'display_time':local.strftime('%d %b %Y · %H:%M:%S'),'epoch':now,'event':'vault_unlock_'+outcome,'outcome':outcome,'source':'local vault authentication'}
 fd=os.open(INCIDENTS,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
 try:
  os.write(fd,(json.dumps(entry,ensure_ascii=False)+'\n').encode()); os.fsync(fd)
 finally:os.close(fd)
 try:os.chmod(INCIDENTS,0o600)
 except OSError:pass
 return entry

def log_failed_unlock(): return _log_unlock_event('failed')
def log_successful_unlock(): return _log_unlock_event('success')
def log_lockout_event(duration):
 ensure_dirs();now=time.time();local=datetime.datetime.fromtimestamp(now).astimezone();entry={'id':uuid.uuid4().hex,'timestamp':local.isoformat(timespec='seconds'),'display_time':local.strftime('%d %b %Y · %H:%M:%S'),'epoch':now,'event':'vault_lockout','outcome':'blocked','duration_seconds':int(duration),'source':'local vault protection'}
 fd=os.open(INCIDENTS,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
 try:os.write(fd,(json.dumps(entry,ensure_ascii=False)+'\n').encode());os.fsync(fd)
 finally:os.close(fd)
 try:os.chmod(INCIDENTS,0o600)
 except OSError:pass
 return entry
def load_unlock_incidents():
 if not INCIDENTS.exists():return []
 rows=[]
 try:
  for line in INCIDENTS.read_text(errors='replace').splitlines():
   try:
    r=json.loads(line)
    if r.get('event') in ('vault_unlock_failed','vault_unlock_success','vault_lockout') and r.get('epoch') is not None:rows.append(r)
   except Exception:continue
 except OSError:pass
 return rows

def clear_unlock_incidents():
 ensure_dirs();write_atomic(INCIDENTS,b'',0o600)
def settings():
 defaults={'suspend_after_failures':False,'failure_threshold':3,'failures':0}
 try: defaults.update(json.loads(SETTINGS.read_text()))
 except Exception: pass
 return defaults
def save_settings(s): write_atomic(SETTINGS,json.dumps(s,indent=2).encode())
def reset_failures(): s=settings();s['failures']=0;save_settings(s)
