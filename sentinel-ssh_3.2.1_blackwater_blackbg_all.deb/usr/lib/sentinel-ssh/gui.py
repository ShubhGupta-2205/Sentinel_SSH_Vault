#!/usr/bin/python3
import tkinter as tk
from tkinter import filedialog,messagebox,simpledialog,ttk
import os,sys,time,subprocess,tempfile,random,shutil,json,datetime,select,collections,uuid
from PIL import Image, ImageDraw, ImageFilter, ImageTk
from pathlib import Path
sys.path.insert(0,'/usr/lib/sentinel-ssh'); import vault, ssh_analyzer
BG='#080a0e'; PANEL='#11151c'; PANEL2='#171d26'; GLASS='#10151d'; TEXT='#e7edf5'; MUTED='#929eae'; BLUE='#438fff'; CYAN='#7db7ff'; RED='#f05252'; GREEN='#36c98a'; AMBER='#ffb547'; TIMEOUT=300; WALLPAPER='/usr/share/sentinel-ssh/bluewater-wallpaper.png'
class App:
 def __init__(self,root):
  self.root=root;self.master=None;self.analyzer_stoppers=[];self.items=[];self.last_activity=time.monotonic();self.tempdir=None;self.settings=vault.settings();self.view_mode=self.settings.get('view_mode','list');self.lockout_until=float(self.settings.get('lockout_until',0));root.title('Sentinel SSH Secure Vault | Blackwater Edition');root.geometry('1060x720');root.minsize(820,580);root.configure(bg=BG)
  self.bg=tk.Canvas(root,bg=BG,highlightthickness=0);self.bg.place(x=0,y=0,relwidth=1,relheight=1);self.wallpaper_source=None;self.wallpaper_photo=None;self.wallpaper_item=None
  try:self.wallpaper_source=Image.open(WALLPAPER).convert('RGB')
  except Exception:self.wallpaper_source=None
  self.update_wallpaper();root.bind('<Configure>',self.update_wallpaper)
  self.workspace=tk.Frame(root,bg=BG);self.workspace.place(relx=.035,rely=.035,relwidth=.93,relheight=.93);self.mainpage=tk.Frame(self.workspace,bg=BG);self.mainpage.pack(fill='both',expand=True);self.ownerpage=tk.Frame(self.workspace,bg=BG);self.selected_indices=set();self.tile_bg_photo=None;self.build();root.bind_all('<KeyPress>',self.activity);root.bind_all('<ButtonPress>',self.activity);root.protocol('WM_DELETE_WINDOW',self.close);self.show_lock();self.tick()
 def update_wallpaper(self,event=None):
  if event and event.widget is not self.root:return
  if not self.wallpaper_source:return
  try:
   w=max(1,self.root.winfo_width());h=max(1,self.root.winfo_height());src=self.wallpaper_source
   scale=max(w/src.width,h/src.height);size=(int(src.width*scale),int(src.height*scale));im=src.resize(size,Image.Resampling.LANCZOS);left=(im.width-w)//2;top=(im.height-h)//2;im=im.crop((left,top,left+w,top+h))
   # Blackwater uses a restrained near-black backdrop; wallpaper is disabled by default.
   im=Image.new('RGB',(w,h),(8,10,14))
   self.wallpaper_photo=ImageTk.PhotoImage(im)
   if self.wallpaper_item is None:self.wallpaper_item=self.bg.create_image(0,0,anchor='nw',image=self.wallpaper_photo)
   else:self.bg.itemconfigure(self.wallpaper_item,image=self.wallpaper_photo)
   self.bg.tag_lower(self.wallpaper_item)
  except Exception:pass
 def transition(self,target):
  current=self.mainpage if target is self.ownerpage else self.ownerpage
  current.pack_forget();current.place_forget();target.pack_forget()
  # Brief, eased slide-in motion to make navigation feel alive without flicker.
  target.place(relx=0.025 if target is self.ownerpage else -0.025,rely=0,relwidth=1,relheight=1)
  def step(i=0):
   if i>=6:target.place(relx=0,rely=0,relwidth=1,relheight=1);return
   start=0.025 if target is self.ownerpage else -0.025;target.place(relx=start*(1-i/6),rely=0,relwidth=1,relheight=1);self.root.after(12,lambda:step(i+1))
  step()
 def build(self):
  head=tk.Frame(self.mainpage,bg=BG);head.pack(fill='x',pady=(8,12));tk.Label(head,text='SENTINEL  ·  SECURE VAULT',bg=BG,fg=TEXT,font=('Sans',21,'bold')).pack(side='left');self.button(head,'OWNER CONTROL CENTER  ⚙',self.show_owner).pack(side='right')
  tk.Label(self.mainpage,text='BLACKWATER EDITION  ·  LOCAL-FIRST SECURITY',bg=BG,fg=MUTED,font=('Monospace',9)).pack(anchor='w',pady=(0,14))
  toolbar=tk.Frame(self.mainpage,bg=BG);toolbar.pack(fill='x',pady=4)
  for txt,fn in [('＋ Files',self.import_files),('＋ Folder',self.import_folder),('↗ Open',self.open_selected),('Export',self.export_selected),('Delete selected',self.delete_selected),('Threat Analyzer',self.analyzer_window),('Lock',self.lock)]:self.button(toolbar,txt,fn).pack(side='left',padx=(0,6))
  self.view_button=self.button(toolbar,'▦ Tiles' if self.view_mode=='grid' else '☰ List',self.toggle_view);self.view_button.pack(side='right',padx=(6,0))
  holder=tk.Frame(self.mainpage,bg=GLASS,highlightbackground='#2b394b',highlightthickness=1);holder.pack(fill='both',expand=True,pady=12)
  self.list=tk.Canvas(holder,bg=BG,highlightthickness=0,relief='flat',borderwidth=0);self.list.pack(fill='both',expand=True,padx=8,pady=8);self.list.bind('<Configure>',lambda e:self.draw_tiles());self.list.bind('<Button-1>',self.tile_click);self.list.bind('<Double-Button-1>',lambda e:self.open_selected());self.list.bind('<MouseWheel>',lambda e:self.list.yview_scroll(-1 if e.delta>0 else 1,'units'));self.list.bind('<Button-4>',lambda e:self.list.yview_scroll(-1,'units'));self.list.bind('<Button-5>',lambda e:self.list.yview_scroll(1,'units'))
  foot=tk.Frame(self.mainpage,bg=BG);foot.pack(fill='x');self.info=tk.Label(foot,text='LOCKED',bg=BG,fg=CYAN,font=('Monospace',9));self.info.pack(side='left');tk.Label(foot,text='AUTO-LOCK · 5 MIN · COPY-ONLY IMPORT',bg=BG,fg=MUTED,font=('Monospace',8)).pack(side='right')
  self.build_owner_page()
 def build_owner_page(self):
  head=tk.Frame(self.ownerpage,bg=BG);head.pack(fill='x',pady=(8,16));tk.Label(head,text='OWNER CONTROL CENTER',bg=BG,fg=TEXT,font=('Sans',22,'bold')).pack(side='left');self.button(head,'← BACK TO VAULT',self.show_main).pack(side='right')
  tk.Label(self.ownerpage,text='OWNER-VERIFIED SECURITY AND VAULT MANAGEMENT',bg=BG,fg=MUTED,font=('Monospace',9)).pack(anchor='w',pady=(0,12))
  body=tk.Frame(self.ownerpage,bg=GLASS,highlightbackground='#2b394b',highlightthickness=1);body.pack(fill='both',expand=True)
  cards=[('OVERVIEW','Security overview',self.security_overview,'◉'),('ANALYSIS','Vault brute-force analyzer',self.analyzer_window,'⌁'),('AUDIT','Owner audit trail',self.audit_trail,'≡'),('INTEGRITY','Verify encrypted vault',self.integrity_scan,'✓'),('SECURITY','Change vault password',self.change_password,'⌑'),('INCIDENTS','Failed-unlock history',self.incidents,'◷'),('PROTECTION','Lockout settings',self.security_settings,'⚠'),('VAULT','Empty vault',self.empty_vault,'▣'),('VAULT','Delete entire vault',self.delete_vault,'⌫'),('SESSION','Lock vault now',self.lock,'◈')]
  self.owner_tiles=[]
  for i,(section,label,command,ico) in enumerate(cards):
   r=i//3;c=i%3;card=tk.Frame(body,bg=PANEL2,highlightbackground='#2b394b',highlightthickness=1,cursor='hand2');card.grid(row=r,column=c,sticky='nsew',padx=12,pady=12)
   tk.Label(card,text=ico,bg=PANEL2,fg=CYAN,font=('Sans',24)).pack(pady=(12,4));tk.Label(card,text=section,bg=PANEL2,fg=CYAN,font=('Monospace',8,'bold')).pack();tk.Label(card,text=label,bg=PANEL2,fg=TEXT,font=('Sans',10,'bold'),wraplength=160).pack(pady=(6,12))
   for widget in (card,*card.winfo_children()):widget.bind('<Button-1>',lambda e,fn=command:fn());widget.bind('<Enter>',lambda e,frame=card:frame.configure(bg='#20344d'));widget.bind('<Leave>',lambda e,frame=card:frame.configure(bg=PANEL2))
   self.owner_tiles.append(card)
  for c in range(3):body.grid_columnconfigure(c,weight=1,uniform='owner');
  for r in range((len(cards)+2)//3):body.grid_rowconfigure(r,weight=1,uniform='owner')
 def show_owner(self):
  if not self.unlocked():return
  self.transition(self.ownerpage);self.activity()
 def show_main(self):
  self.transition(self.mainpage);self.activity()
 def button(self,p,t,c):
  b=tk.Button(p,text=t,command=c,bg=PANEL2,fg=TEXT,activebackground='#25384f',activeforeground=CYAN,relief='flat',bd=0,padx=11,pady=8,font=('Sans',9,'bold'),cursor='hand2');b.bind('<Enter>',lambda e:b.configure(bg='#20344d',fg=CYAN));b.bind('<Leave>',lambda e:b.configure(bg=PANEL2,fg=TEXT));return b
 def activity(self,e=None):self.last_activity=time.monotonic()
 def tick(self):
  if self.master and time.monotonic()-self.last_activity>=TIMEOUT:self.lock()
  self.root.after(1000,self.tick)
 def show_lock(self):
  self.overlay=tk.Frame(self.root,bg='#0b0e13',highlightthickness=1,highlightbackground='#23608a');self.overlay.place(relx=.5,rely=.5,anchor='center',relwidth=.43,relheight=.55)
  tk.Label(self.overlay,text='◈',bg='#0b0e13',fg=CYAN,font=('Sans',36)).pack(pady=(22,2));tk.Label(self.overlay,text='VAULT LOCKED' if vault.KEYFILE.exists() else 'CREATE VAULT',bg='#0b0e13',fg=TEXT,font=('Sans',16,'bold')).pack();tk.Label(self.overlay,text='Authenticate to enter your private workspace',bg='#0b0e13',fg=MUTED,font=('Sans',9)).pack(pady=(6,18))
  self.pw=tk.Entry(self.overlay,show='●',bg=PANEL2,fg=TEXT,insertbackground=CYAN,relief='flat',font=('Sans',12));self.pw.pack(fill='x',padx=30,ipady=10);self.pw.bind('<Return>',lambda e:self.unlock())
  self.error=tk.Label(self.overlay,text='',bg='#0b0e13',fg=RED,font=('Sans',9));self.error.pack(pady=8);self.button(self.overlay,'UNLOCK / CREATE',self.unlock).pack(fill='x',padx=30,pady=10);self.pw.focus_set()
 def unlock(self):
  remaining=max(0,int(self.lockout_until-time.time()))
  if remaining>0:self.error.config(text=f'LOCKOUT ACTIVE · try again in {remaining}s');return
  if self.lockout_until and self.lockout_until<=time.time():
   s=vault.settings();s['failures']=0;s['lockout_until']=0;vault.save_settings(s);self.lockout_until=0
  p=self.pw.get()
  if len(p)<10:self.error.config(text='Password must be at least 10 characters.');return
  try:
   if not vault.KEYFILE.exists():
    q=simpledialog.askstring('Confirm password','Repeat your new password:',show='●',parent=self.root)
    if p!=q:self.error.config(text='Passwords did not match.');return
    self.master=vault.init_vault(p);vault.reset_failures()
   else:
    try:self.master=vault.unlock(p);vault.log_successful_unlock();vault.reset_failures()
    except Exception:
     vault.log_failed_unlock();s=vault.settings();s['failures']=int(s.get('failures',0))+1;vault.save_settings(s);self.settings=s;count=s['failures'];self.error.config(text=f'Authentication failed · logged at {time.strftime("%H:%M:%S")} · {count}/5 attempts');
     if count>=5:
      s['lockout_until']=time.time()+60;s['failures']=5;vault.save_settings(s);self.lockout_until=float(s['lockout_until']);vault.log_lockout_event(60);messagebox.showwarning('Five failed attempts','Vault locked for 60 seconds. Sentinel will now close.');self.root.after(100,self.close);
     self.pw.delete(0,'end');return
   self.items=vault.load_manifest(self.master);self.overlay.destroy();self.overlay=None;self.last_activity=time.monotonic();self.refresh()
  except Exception as e:self.master=None;self.error.config(text='Vault error: '+str(e)[:100])
 def refresh(self):
  self.selected_indices=set();self.draw_tiles();self.info.config(text=f'UNLOCKED · {len(self.items)} FILES · AUTOLOCK 05:00')
 def toggle_view(self):
  self.view_mode='grid' if self.view_mode=='list' else 'list';self.settings=vault.settings();self.settings['view_mode']=self.view_mode;vault.ensure_dirs();vault.save_settings(self.settings);self.view_button.config(text='▦ Tiles' if self.view_mode=='grid' else '☰ List');self.draw_tiles()
 def draw_tiles(self):
  if not hasattr(self,'list') or not self.list.winfo_exists():return
  self.list.delete('all');w=max(300,self.list.winfo_width());pad=12
  # Professional Blackwater edition: tile area remains solid black.
  if self.view_mode=='list':
   rowh=62
   for i,it in enumerate(self.items):
    y=pad+i*rowh;fill='#20344d' if i in self.selected_indices else '#0b2138';outline='#438fff' if i in self.selected_indices else '#2b394b';self.list.create_rectangle(pad,y,w-pad,y+48,fill=fill,outline=outline,width=1,tags=('tile',f'idx{i}'));self.list.create_text(pad+18,y+24,anchor='w',text='◆',fill=CYAN,tags=('tile',f'idx{i}'));self.list.create_text(pad+42,y+24,anchor='w',text=it.get('path',it['name']),fill=TEXT,font=('Monospace',10),tags=('tile',f'idx{i}'));self.list.create_text(w-pad-12,y+24,anchor='e',text=f"{it['size']:,} B",fill=MUTED,font=('Monospace',9),tags=('tile',f'idx{i}'))
   self.list.configure(scrollregion=(0,0,w,pad+len(self.items)*(62 if self.view_mode=='list' else 140)+pad))
  else:
   tilew=170;tileh=132;gap=12;cols=max(1,(w-2*pad+gap)//(tilew+gap));actualw=(w-2*pad-gap*(cols-1))//cols
   for i,it in enumerate(self.items):
    r=i//cols;c=i%cols;x=pad+c*(actualw+gap);y=pad+r*(tileh+gap);fill='#20344d' if i in self.selected_indices else '#0b2138';outline='#438fff' if i in self.selected_indices else '#2b394b';self.list.create_rectangle(x,y,x+actualw,y+tileh,fill=fill,outline=outline,width=2 if i in self.selected_indices else 1,tags=('tile',f'idx{i}'));self.list.create_text(x+actualw//2,y+28,text='◆',fill=CYAN,font=('Sans',20),tags=('tile',f'idx{i}'));self.list.create_text(x+actualw//2,y+65,text=it.get('path',it['name']),fill=TEXT,font=('Monospace',9),width=actualw-12,tags=('tile',f'idx{i}'));self.list.create_text(x+actualw//2,y+tileh-14,text=f"{it['size']:,} B",fill=MUTED,font=('Monospace',8),tags=('tile',f'idx{i}'))
   self.list.configure(scrollregion=(0,0,w,pad+((len(self.items)+cols-1)//cols)*(tileh+gap)+pad))
 def tile_click(self,event):
  ids=self.list.find_withtag('current');idx=None
  for tag in self.list.gettags('current'):
   if tag.startswith('idx'):idx=int(tag[3:]);break
  if idx is None:return
  if event.state & 0x0004:self.selected_indices.symmetric_difference_update({idx})
  else:self.selected_indices={idx}
  self.draw_tiles()
 def unlocked(self):
  if not self.master:messagebox.showinfo('Locked','Unlock the vault first.');return False
  return True
 def import_paths(self,paths):
  if not self.unlocked():return
  added=0
  try:
   for raw in paths:
    p=Path(raw); files=list(p.rglob('*')) if p.is_dir() else [p]
    for f in files:
     if not f.is_file() or f.is_symlink():continue
     rel=str(f.relative_to(p)) if p.is_dir() else f.name
     self.items.append(vault.encrypt_file(self.master,f,rel));added+=1
   vault.save_manifest(self.master,self.items);vault.audit(self.master,'IMPORT',f'{added} file(s)');self.refresh();messagebox.showinfo('Imported',f'{added} file(s) encrypted. Source files were not changed.')
  except Exception as e:messagebox.showerror('Import error',f'{added} added before error:\n{e}')
 def import_files(self):
  p=filedialog.askopenfilenames();
  if p:self.import_paths(p)
 def import_folder(self):
  p=filedialog.askdirectory();
  if p:self.import_paths([p])
 def selected(self):return sorted(self.selected_indices)
 def open_selected(self):
  if not self.unlocked():return
  ids=self.selected()
  if not ids:messagebox.showinfo('Select','Select one or more files.');return
  if len(ids)>1:messagebox.showinfo('Open','Choose one file to open at a time.');return
  item=self.items[ids[0]]
  try:
   if self.tempdir is None:self.tempdir=tempfile.mkdtemp(prefix='sentinel-open-');os.chmod(self.tempdir,0o700)
   dest=Path(self.tempdir)/item['name'];dest.write_bytes(vault.decrypt_file(self.master,item));os.chmod(dest,0o600);subprocess.Popen(['xdg-open',str(dest)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True);vault.audit(self.master,'OPEN',item.get('name','file'))
   messagebox.showwarning('Decrypted temporary copy','Opened a temporary decrypted copy. External apps may make other copies. Sentinel removes its temporary workspace when you lock or exit; it cannot guarantee erasure of external copies.')
  except Exception as e:messagebox.showerror('Open failed',str(e))
 def export_selected(self):
  if not self.unlocked():return
  ids=self.selected();
  if not ids:messagebox.showinfo('Select','Select files to export.');return
  for i in ids:
   it=self.items[i];dest=filedialog.asksaveasfilename(initialfile=Path(it.get('path',it['name'])).name,title='Export decrypted copy')
   if not dest:break
   try:Path(dest).write_bytes(vault.decrypt_file(self.master,it));os.chmod(dest,0o600);vault.audit(self.master,'EXPORT',it.get('name','file'))
   except Exception as e:messagebox.showerror('Export failed',str(e))
  messagebox.showwarning('Export warning','Exports are decrypted. Securely handle exported files.')
 def verify(self):
  p=simpledialog.askstring('Confirm owner','Enter vault password:',show='●',parent=self.root)
  if p is None:return False
  try:vault.unlock(p);return True
  except Exception:messagebox.showerror('Failed','Incorrect password.');return False
 def delete_selected(self):
  if not self.unlocked():return
  ids=self.selected()
  if not ids:return
  if not self.verify() or not messagebox.askyesno('Delete permanently',f'Remove {len(ids)} encrypted item(s)? This cannot be undone.'):return
  for i in reversed(ids): (vault.OBJECTS/self.items[i]['id']).unlink(missing_ok=True);self.items.pop(i)
  vault.save_manifest(self.master,self.items);vault.audit(self.master,'DELETE',f'{len(ids)} item(s)');self.refresh()
 def owner(self):
  if not self.unlocked():return
  m=tk.Menu(self.root,tearoff=0);m.add_command(label='Change password…',command=self.change_password);m.add_command(label='Incident history (failed unlocks)',command=self.incidents);m.add_command(label='Failure response settings…',command=self.security_settings);m.add_separator();m.add_command(label='Empty vault…',command=self.empty_vault);m.add_command(label='Delete entire vault…',command=self.delete_vault);m.add_separator();m.add_command(label='Lock now',command=self.lock);m.tk_popup(self.root.winfo_pointerx(),self.root.winfo_pointery())
 def analyzer_window(self):
  if not self.unlocked():return
  win=tk.Toplevel(self.root);win.title('Sentinel Vault Brute-Force Analyzer · Local & Offline');win.geometry('1080x740');win.minsize(900,620);win.configure(bg=BG)
  analyzer=ssh_analyzer.LogAnalyzer()
  try:analyzer.events=vault.load_analyzer_events(self.master)
  except Exception:analyzer.events=[]
  # Rebuild dedup state for persisted events, including event IDs from vault log.
  for e in analyzer.events:
   if e.get('event_type')=='vault_unlock':analyzer.seen.add(('vault',str(e.get('id'))))
  live={'active':True,'last_sync':0.0}
  head=tk.Frame(win,bg=BG);head.pack(fill='x',padx=14,pady=(12,5));tk.Label(head,text='VAULT BRUTE-FORCE ANALYZER',bg=BG,fg=TEXT,font=('Sans',19,'bold')).pack(side='left')
  tk.Label(win,text='LOCAL VAULT AUTHENTICATION · OFFLINE · NO NETWORK · NO DATA UPLOAD',bg=BG,fg=CYAN,font=('Monospace',9)).pack(anchor='w',padx=15,pady=(0,8))
  bar=tk.Frame(win,bg=BG);bar.pack(fill='x',padx=12,pady=4)
  body=tk.Frame(win,bg=GLASS,highlightbackground='#2b394b',highlightthickness=1);body.pack(fill='both',expand=True,padx=12,pady=8)
  summary=tk.Frame(body,bg=GLASS);summary.pack(fill='x',padx=8,pady=8)
  stat_labels={}
  for name in ('AUTH EVENTS','FAILED','SUCCESSFUL','LOCKOUTS'):
   box=tk.Frame(summary,bg=PANEL2,highlightbackground='#2b394b',highlightthickness=1);box.pack(side='left',fill='x',expand=True,padx=4)
   tk.Label(box,text=name,bg=PANEL2,fg=CYAN,font=('Monospace',8,'bold')).pack(pady=(7,2));lab=tk.Label(box,text='0',bg=PANEL2,fg=TEXT,font=('Sans',19,'bold'));lab.pack(pady=(0,7));stat_labels[name]=lab
  chartrow=tk.Frame(body,bg=GLASS);chartrow.pack(fill='x',padx=8)
  pie=tk.Canvas(chartrow,bg=PANEL,highlightthickness=0,height=190);pie.pack(side='left',fill='both',expand=True,padx=4,pady=4)
  trend=tk.Canvas(chartrow,bg=PANEL,highlightthickness=0,height=190);trend.pack(side='left',fill='both',expand=True,padx=4,pady=4)
  bottom=tk.Frame(body,bg=GLASS);bottom.pack(fill='both',expand=True,padx=8,pady=(2,8))
  tk.Label(bottom,text='LOCAL VAULT AUTHENTICATION RISK PROFILE · NO USER/IP COUNT',bg=GLASS,fg=CYAN,font=('Monospace',9,'bold')).pack(anchor='w',padx=4,pady=4)
  cols=('source','category','attempts','failed','score','risk','first','last')
  style=ttk.Style(win);style.configure('Treeview',background=PANEL,fieldbackground=PANEL,foreground=TEXT,rowheight=26);style.configure('Treeview.Heading',background=PANEL2,foreground=CYAN);style.map('Treeview',background=[('selected','#20344d')],foreground=[('selected',TEXT)])
  tree=ttk.Treeview(bottom,columns=cols,show='headings',height=6,style='Treeview')
  headings={'source':'SOURCE','category':'EVENT TYPE','attempts':'ATTEMPTS','failed':'FAILED','score':'RISK','risk':'LEVEL','first':'FIRST SEEN','last':'LAST SEEN'}
  widths={'source':150,'category':155,'attempts':85,'failed':80,'score':65,'risk':80,'first':140,'last':140}
  for c in cols:tree.heading(c,text=headings[c]);tree.column(c,width=widths[c],anchor='center')
  tree.pack(fill='both',expand=True)
  footer=tk.Label(win,text='Waiting for vault authentication events · monitoring can remain active while this window is minimized.',bg=BG,fg=MUTED,font=('Monospace',8));footer.pack(anchor='w',padx=15,pady=(0,8))
  def sync_vault_events():
   added=[]
   for row in vault.load_unlock_incidents():
    e=analyzer.add_vault_event(row)
    if e:added.append(e)
   if added:vault.save_analyzer_events(self.master,analyzer.events)
   return len(added)
  def clear():
   if not messagebox.askyesno('Clear vault analyzer history','Delete all recorded vault authentication events and analysis history? This clears the local failed/successful unlock event log too.',parent=win):return
   analyzer.clear();vault.save_analyzer_events(self.master,[]);vault.clear_unlock_incidents();vault.audit(self.master,'CLEAR_ANALYZER_HISTORY','Authentication journal cleared');render();footer.config(text='HISTORY CLEARED · waiting for new vault authentication events')
  def demo():
   if not messagebox.askyesno('Load simulation','Add clearly labeled simulated vault unlock events? These are not real password attempts.',parent=win):return
   now=time.time();samples=[('failed',-54),('failed',-42),('failed',-31),('failed',-20),('success',-8)]
   for outcome,delta in samples:
    epoch=now+delta;local=datetime.datetime.fromtimestamp(epoch).astimezone();row={'id':'demo-'+uuid.uuid4().hex,'epoch':epoch,'timestamp':local.isoformat(timespec='seconds'),'display_time':local.strftime('%d %b %Y · %H:%M:%S'),'event':'vault_unlock_'+outcome,'outcome':outcome,'source':'SIMULATION'}
    e=analyzer.add_vault_event(row)
    if e:e['source']='SIMULATED';e['event_type']='vault_unlock_simulated'
   vault.save_analyzer_events(self.master,analyzer.events);render();footer.config(text='SIMULATION · synthetic unlock events · clearly marked · not real attempts')
  def toggle_live():
   live['active']=not live['active'];btn_live.config(text='■ Pause live updates' if live['active'] else '● Resume live updates')
   if live['active']:
    sync_vault_events();render();footer.config(text='LIVE · watching local vault authentication event log · works while minimized')
   else:footer.config(text='LIVE UPDATES PAUSED · events remain recorded locally and sync when resumed/reopened')
  def poll():
   if not win.winfo_exists():return
   if live['active']:
    try:
     if sync_vault_events():render()
    except Exception as ex:footer.config(text='MONITOR ERROR · '+str(ex)[:120])
   win.after(650,poll)
  def profile_detail(event=None):
   selected=tree.selection()
   if not selected:return
   result=ssh_analyzer.analyze(analyzer.events);p=next((x for x in result['profiles'] if x['ip']=='LOCAL VAULT'),None)
   if not p:return
   detail=tk.Toplevel(win);detail.title('Vault Authentication Analysis');detail.configure(bg=BG);detail.geometry('560x460')
   tk.Label(detail,text='LOCAL VAULT',bg=BG,fg=TEXT,font=('Sans',17,'bold')).pack(anchor='w',padx=14,pady=(14,3))
   tk.Label(detail,text=f"{p['severity'].upper()} RISK · SCORE {p['risk_score']}/100 · PASSWORD-GUESSING ANALYSIS",bg=BG,fg=CYAN,font=('Monospace',9)).pack(anchor='w',padx=14)
   relevant=[e for e in analyzer.events if e.get('source_ip')=='LOCAL VAULT' and e.get('event_type') in ('vault_unlock','vault_lockout')]
   lines=[]
   for e in sorted(relevant,key=lambda x:x['epoch'],reverse=True)[:30]:
    stamp=datetime.datetime.fromtimestamp(e['epoch']).astimezone().strftime('%Y-%m-%d %H:%M:%S')
    label='SUCCESSFUL UNLOCK' if e['outcome']=='success' else ('LOCKOUT ACTIVATED' if e['outcome']=='blocked' else 'FAILED PASSWORD')
    lines.append(f"{stamp}  ·  {label}  ·  {e.get('source','recorded')}")
   details=f"Total authentication events: {p['attempts']}\nFailed attempts: {p['failed']}\nSuccessful unlocks: {p['success']}\nPattern: {p['pattern']}\nAttempts in last 5 minutes: {p['attempts_5m']}\nFirst seen: {datetime.datetime.fromtimestamp(p['first']).astimezone().strftime('%Y-%m-%d %H:%M:%S')}\nLast seen: {datetime.datetime.fromtimestamp(p['last']).astimezone().strftime('%Y-%m-%d %H:%M:%S')}\nDuration: {p['duration']:.1f} seconds\n\nRECENT EVENT TIMELINE\n"+'\n'.join(lines)
   tk.Label(detail,text=details,bg=PANEL,fg=TEXT,font=('Monospace',10),justify='left',anchor='nw',padx=14,pady=12).pack(fill='both',expand=True,padx=14,pady=12)
  tree.bind('<Double-1>',profile_detail)
  def render():
   result=ssh_analyzer.analyze(analyzer.events);total=result['total'];fail=result['failed'];succ=result['successful'];vault_events=[e for e in analyzer.events if e.get('source_ip')=='LOCAL VAULT' and e.get('event_type')=='vault_unlock'];fail_v=sum(e['outcome']=='failed' for e in vault_events);succ_v=sum(e['outcome']=='success' for e in vault_events);lockouts=sum(e.get('event_type')=='vault_lockout' for e in analyzer.events)
   stat_labels['AUTH EVENTS'].config(text=str(len(vault_events)));stat_labels['FAILED'].config(text=str(fail_v));stat_labels['SUCCESSFUL'].config(text=str(succ_v));stat_labels['LOCKOUTS'].config(text=str(lockouts))
   pie.delete('all');pw=max(300,pie.winfo_width());pie.create_text(12,12,anchor='nw',text='VAULT AUTHENTICATION OUTCOMES',fill=CYAN,font=('Monospace',9,'bold'))
   if vault_events:
    x0=max(20,pw//2-64);y0=34;x1=x0+126;y1=y0+126;angle=90
    for val,color,label in ((fail_v,'#ff7189','Failed'),(succ_v,'#53d5e7','Successful')):
     extent=360*val/max(1,len(vault_events))
     if extent>0:pie.create_arc(x0,y0,x1,y1,start=angle,extent=extent,style='pieslice',fill=color,outline=PANEL);angle-=extent
    pie.create_oval(x0+32,y0+32,x1-32,y1-32,fill=PANEL,outline=PANEL);pie.create_text((x0+x1)//2,(y0+y1)//2,text=str(len(vault_events)),fill=TEXT,font=('Sans',14,'bold'));pie.create_text(x1+12,y0+35,anchor='nw',text=f'Failed  {fail_v}',fill='#ff7189',font=('Sans',10));pie.create_text(x1+12,y0+60,anchor='nw',text=f'Success  {succ_v}',fill='#53d5e7',font=('Sans',10))
   trend.delete('all');tw=max(300,trend.winfo_width());trend.create_text(12,12,anchor='nw',text='VAULT AUTH EVENTS OVER TIME',fill=CYAN,font=('Monospace',9,'bold'))
   if vault_events:
    buckets=collections.Counter();start=min(e['epoch'] for e in vault_events);end=max(e['epoch'] for e in vault_events);span=max(1,end-start);n=8
    for e in vault_events:buckets[min(n-1,int((e['epoch']-start)/span*n))]+=1
    maxv=max(buckets.values()) or 1;xleft=38;xright=tw-15;ybottom=160;ytop=35;trend.create_line(xleft,ybottom,xright,ybottom,fill='#31516b');points=[]
    for i in range(n):
     x=xleft+(xright-xleft)*i/(n-1);v=buckets[i];y=ybottom-(ybottom-ytop)*v/maxv;points.append((x,y));trend.create_oval(x-3,y-3,x+3,y+3,fill=CYAN,outline=CYAN);trend.create_text(x,y-12,text=str(v),fill=TEXT,font=('Sans',8))
    if len(points)>1:trend.create_line(*[coord for point in points for coord in point],fill=BLUE,width=2,smooth=True)
   for row in tree.get_children():tree.delete(row)
   p=next((x for x in result['profiles'] if x['ip']=='LOCAL VAULT'),None)
   if p:
    first=datetime.datetime.fromtimestamp(p['first']).astimezone().strftime('%Y-%m-%d %H:%M:%S');last=datetime.datetime.fromtimestamp(p['last']).astimezone().strftime('%Y-%m-%d %H:%M:%S');tree.insert('', 'end',values=('LOCAL VAULT','Password unlock',p['attempts'],p['failed'],p['risk_score'],p['severity'].upper(),first,last))
  btn_live=self.button(bar,'■ Pause live updates',toggle_live);btn_live.pack(side='left',padx=3)
  self.button(bar,'Load demo data',demo).pack(side='left',padx=3)
  self.button(bar,'Clear history',clear).pack(side='left',padx=3)
  self.button(bar,'Close',win.destroy).pack(side='right',padx=3)
  for canvas in (pie,trend):canvas.bind('<Configure>',lambda e:render())
  sync_vault_events();render();footer.config(text='LIVE · monitoring enabled automatically · local authentication events only');poll()
  def close_window():
   live['active']=False
   if close_window in self.analyzer_stoppers:self.analyzer_stoppers.remove(close_window)
   win.destroy()
  self.analyzer_stoppers.append(close_window)
  win.protocol('WM_DELETE_WINDOW',close_window)
 def security_overview(self):
  if not self.unlocked():return
  win=tk.Toplevel(self.root);win.title('Sentinel · Security Overview');win.geometry('760x540');win.configure(bg=BG)
  tk.Label(win,text='SECURITY OVERVIEW',bg=BG,fg=TEXT,font=('Sans',20,'bold')).pack(anchor='w',padx=18,pady=(16,4))
  tk.Label(win,text='Live metrics derived from the local authentication journal',bg=BG,fg=MUTED,font=('Monospace',9)).pack(anchor='w',padx=18,pady=(0,12))
  rows=vault.load_unlock_incidents();failed=sum(r.get('outcome')!='success' for r in rows);success=sum(r.get('outcome')=='success' for r in rows);lockouts=sum(r.get('event')=='vault_lockout' for r in rows);total=len(rows)
  stats=tk.Frame(win,bg=BG);stats.pack(fill='x',padx=12)
  for label,value,color in [('AUTH EVENTS',total,BLUE),('FAILED',failed,RED),('SUCCESSFUL',success,GREEN),('LOCKOUTS',lockouts,AMBER)]:
   card=tk.Frame(stats,bg=PANEL2,highlightbackground='#2b394b',highlightthickness=1);card.pack(side='left',fill='both',expand=True,padx=4,pady=4);tk.Label(card,text=label,bg=PANEL2,fg=MUTED,font=('Monospace',8,'bold')).pack(pady=(9,2));tk.Label(card,text=str(value),bg=PANEL2,fg=color,font=('Sans',22,'bold')).pack(pady=(0,9))
  body=tk.Frame(win,bg=PANEL,highlightbackground='#2b394b',highlightthickness=1);body.pack(fill='both',expand=True,padx=16,pady=12)
  size=sum((vault.OBJECTS/i['id']).stat().st_size for i in self.items if (vault.OBJECTS/i['id']).exists())
  facts=[('Vault state','Unlocked in this session'),('Encrypted objects',str(len(self.items))),('Encrypted storage',f'{size:,} bytes'),('Lockout policy','5 failures · 60 seconds'),('Monitoring data','Local-only · no network lookups'),('Security score','Not calculated yet — score requires explicit checks')]
  for k,v in facts:
   row=tk.Frame(body,bg=PANEL);row.pack(fill='x',padx=12,pady=7);tk.Label(row,text=k,bg=PANEL,fg=MUTED,font=('Sans',10)).pack(side='left');tk.Label(row,text=v,bg=PANEL,fg=TEXT,font=('Sans',10,'bold')).pack(side='right')
  tk.Label(win,text='No fabricated score or sample metrics are used on this screen.',bg=BG,fg=CYAN,font=('Monospace',9)).pack(anchor='w',padx=18,pady=(0,12))
 def integrity_scan(self):
  if not self.unlocked():return
  win=tk.Toplevel(self.root);win.title('Vault Integrity Verification');win.geometry('650x470');win.configure(bg=BG)
  tk.Label(win,text='VAULT INTEGRITY SCAN',bg=BG,fg=TEXT,font=('Sans',18,'bold')).pack(anchor='w',padx=16,pady=(14,5))
  tk.Label(win,text='Each encrypted object is authenticated and decrypted in memory for verification.',bg=BG,fg=MUTED,wraplength=600).pack(anchor='w',padx=16,pady=(0,10))
  box=tk.Text(win,bg=PANEL,fg=TEXT,relief='flat',font=('Monospace',10),wrap='word');box.pack(fill='both',expand=True,padx=14,pady=8)
  verified=0;issues=[]
  for item in self.items:
   try:
    vault.decrypt_file(self.master,item);verified+=1;box.insert('end',f"PASS  {item.get('name','object')}\n")
   except Exception as exc:
    issues.append(item.get('name','object'));box.insert('end',f"FAIL  {item.get('name','object')}  ·  {type(exc).__name__}\n")
  result='VERIFIED' if not issues else 'ISSUES FOUND'
  box.insert('end',f"\nRESULT: {result}\nVerified: {verified} / {len(self.items)}\nFailed: {len(issues)}\n")
  box.configure(state='disabled');vault.audit(self.master,'INTEGRITY_SCAN',f'{verified}/{len(self.items)} verified; {len(issues)} failed')
  tk.Label(win,text=f'{result} · {verified}/{len(self.items)} objects authenticated',bg=BG,fg=GREEN if not issues else RED,font=('Sans',11,'bold')).pack(pady=8)
 def audit_trail(self):
  if not self.unlocked():return
  win=tk.Toplevel(self.root);win.title('Sentinel · Owner Audit Trail');win.geometry('760x480');win.configure(bg=BG)
  tk.Label(win,text='OWNER AUDIT TRAIL',bg=BG,fg=TEXT,font=('Sans',18,'bold')).pack(anchor='w',padx=14,pady=(14,4))
  tk.Label(win,text='Security-relevant actions · encrypted local records',bg=BG,fg=MUTED,font=('Monospace',9)).pack(anchor='w',padx=14,pady=(0,8))
  box=tk.Text(win,bg=PANEL,fg=TEXT,relief='flat',font=('Monospace',9),wrap='word');box.pack(fill='both',expand=True,padx=12,pady=12)
  events=vault.load_audit(self.master)
  if not events:box.insert('end','No owner actions recorded yet.\n')
  for e in reversed(events):box.insert('end',f"{e.get('timestamp','')}  ·  {e.get('action','')}  ·  {e.get('detail','')}\n")
  box.configure(state='disabled')
  self.button(win,'Export audit trail',lambda:self.export_audit(events)).pack(pady=(0,12))
 def export_audit(self,events):
  dest=filedialog.asksaveasfilename(title='Export audit trail',defaultextension='.json',filetypes=[('JSON','*.json')])
  if dest:
   try:Path(dest).write_text(json.dumps(events,indent=2,ensure_ascii=False));os.chmod(dest,0o600);messagebox.showinfo('Exported','Audit trail exported. The export is plaintext metadata; protect it appropriately.')
   except Exception as ex:messagebox.showerror('Export failed',str(ex))
 def incidents(self):
  win=tk.Toplevel(self.root);win.title('Sentinel incident history');win.geometry('760x440');win.configure(bg=BG)
  tk.Label(win,text='FAILED UNLOCK HISTORY',bg=BG,fg=TEXT,font=('Sans',15,'bold')).pack(anchor='w',padx=14,pady=(12,4))
  tk.Label(win,text='Times shown in your local system timezone',bg=BG,fg=MUTED,font=('Monospace',9)).pack(anchor='w',padx=14,pady=(0,8))
  box=tk.Text(win,bg=PANEL,fg=TEXT,wrap='word',relief='flat',font=('Monospace',10));box.pack(fill='both',expand=True,padx=12,pady=12)
  lines=[]
  if vault.INCIDENTS.exists():
   for raw in vault.INCIDENTS.read_text(errors='replace').splitlines():
    try:
     e=json.loads(raw);epoch=float(e.get('epoch',0));dt=datetime.datetime.fromtimestamp(epoch).astimezone();stamp=dt.strftime('%d %b %Y · %H:%M:%S');event=e.get('event','security event').replace('_',' ').title();lines.append(f'{stamp}   {event}')
    except Exception:lines.append(raw)
  box.insert('1.0','\n'.join(lines) if lines else 'No failed unlocks recorded.');box.configure(state='disabled')
 def security_settings(self):
  win=tk.Toplevel(self.root);win.title('Failure response');win.configure(bg=BG);win.geometry('440x230')
  tk.Label(win,text='VAULT BRUTE-FORCE PROTECTION',bg=BG,fg=TEXT,font=('Sans',14,'bold')).pack(pady=(18,8))
  tk.Label(win,text='5 incorrect passwords → app closes and 60-second lockout',bg=BG,fg=CYAN,font=('Sans',10)).pack(pady=4)
  tk.Label(win,text='Lockout state is saved, so restarting Sentinel does not bypass it.\nForced sleep is not enabled: it can be abused to deny access.',bg=BG,fg=MUTED,justify='center',wraplength=390).pack(pady=10)
  self.button(win,'Close',win.destroy).pack(pady=8)
 def change_password(self):
  if not self.verify():return
  p=simpledialog.askstring('New password','New password (10+ characters):',show='●',parent=self.root)
  if not p:return
  if len(p)<10:messagebox.showerror('Invalid','Use 10+ characters.');return
  q=simpledialog.askstring('Confirm','Repeat:',show='●',parent=self.root)
  if p!=q:messagebox.showerror('Mismatch','Passwords did not match.');return
  vault.change_password(self.master,p);vault.audit(self.master,'PASSWORD_CHANGE','Password updated');messagebox.showinfo('Changed','Password updated. Encrypted objects were not re-encrypted.')
 def empty_vault(self):
  if not self.verify() or not messagebox.askyesno('Empty vault','Permanently delete ALL encrypted objects?'):return
  for it in self.items:(vault.OBJECTS/it['id']).unlink(missing_ok=True)
  self.items=[];vault.save_manifest(self.master,self.items);vault.audit(self.master,'EMPTY_VAULT','All encrypted objects removed');self.refresh()
 def delete_vault(self):
  if not self.verify() or not messagebox.askyesno('Delete entire vault','Delete Sentinel vault metadata AND encrypted objects? Original imported files remain untouched. This cannot be undone.'):return
  self.close_analyzer_windows();self.show_main();self.cleanup_temp();self.master=None
  shutil.rmtree(vault.ROOT,ignore_errors=False);self.items=[];self.selected_indices=set();self.list.delete('all');self.info.config(text='VAULT DELETED');self.overlay.destroy();self.show_lock()
 def cleanup_temp(self):
  if self.tempdir:
   try:shutil.rmtree(self.tempdir,ignore_errors=True)
   finally:self.tempdir=None
 def close_analyzer_windows(self):
  for stop in list(self.analyzer_stoppers):
   try:stop()
   except Exception:pass
  self.analyzer_stoppers.clear()
  for child in self.root.winfo_children():
   if isinstance(child,tk.Toplevel):
    try:child.destroy()
    except Exception:pass
 def lock(self):
  if self.master is None:return
  self.close_analyzer_windows();self.show_main();self.cleanup_temp();self.master=None;self.items=[];self.selected_indices=set();self.list.delete('all');self.info.config(text='LOCKED');self.show_lock()
 def close(self):self.cleanup_temp();self.master=None;self.items=[];self.root.destroy()
if __name__=='__main__':root=tk.Tk();App(root);root.mainloop()
