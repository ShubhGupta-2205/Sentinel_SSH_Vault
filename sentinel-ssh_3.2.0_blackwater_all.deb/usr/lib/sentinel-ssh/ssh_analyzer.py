#!/usr/bin/python3
"""Offline-first local SSH log analyzer for Sentinel. No network lookups."""
import datetime as dt, ipaddress, re, collections, json

FAIL_RE = re.compile(r"Failed password for (?:invalid user )?(?P<user>\S+) from (?P<ip>[0-9a-fA-F:.]+) port (?P<port>\d+)", re.I)
ACCEPT_RE = re.compile(r"Accepted (?:password|publickey|keyboard-interactive/pam) for (?:invalid user )?(?P<user>\S+) from (?P<ip>[0-9a-fA-F:.]+) port (?P<port>\d+)", re.I)
INVALID_RE = re.compile(r"Invalid user (?P<user>\S+) from (?P<ip>[0-9a-fA-F:.]+)(?: port (?P<port>\d+))?", re.I)
PAM_RE = re.compile(r"authentication failure;.*?rhost=(?P<ip>[0-9a-fA-F:.]+).*?(?:user=(?P<user>\S+))?", re.I)
SYSLOG_RE = re.compile(r"^(?P<mon>Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(?P<day>\d{1,2})\s+(?P<clock>\d{2}:\d{2}:\d{2})")
MONTHS={m:i for i,m in enumerate(('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'),1)}
TEST_NETS=[ipaddress.ip_network(x) for x in ('192.0.2.0/24','198.51.100.0/24','203.0.113.0/24')]
def classify_ip(value):
    try:
        addr=ipaddress.ip_address(value)
        if addr.is_loopback:return 'loopback'
        if addr.is_link_local:return 'link-local'
        if any(addr in n for n in TEST_NETS):return 'documentation/reserved'
        if addr.is_global:return 'public'
        if addr.is_private:return 'private/local'
        return 'reserved/non-public'
    except ValueError:return 'unknown'

def local_epoch(line, fallback=None):
    m=SYSLOG_RE.search(line)
    if not m: return fallback if fallback is not None else dt.datetime.now().timestamp()
    now=dt.datetime.now(); year=now.year
    try:
        stamp=dt.datetime(year,MONTHS[m.group('mon')],int(m.group('day')), *map(int,m.group('clock').split(':')))
        # Handle logs from late December when viewed in early January.
        if stamp.timestamp() > now.timestamp()+86400: stamp=stamp.replace(year=year-1)
        elif stamp.timestamp() < now.timestamp()-330*86400: stamp=stamp.replace(year=year+1)
        return stamp.timestamp()
    except Exception: return fallback if fallback is not None else now.timestamp()

def parse_line(line, fallback=None):
    # Support Sentinel/native JSONL records in addition to syslog text.
    try:
        row=json.loads(line)
        if isinstance(row,dict) and row.get('source_ip'):
            ip=str(row['source_ip']); user=str(row.get('username','unknown')); outcome=str(row.get('outcome',row.get('event','failed'))).lower()
            if 'success' in outcome or outcome in ('accepted','login_ok'): outcome='success'
            else: outcome='failed'
            epoch=float(row.get('epoch') or dt.datetime.fromisoformat(str(row.get('timestamp')).replace('Z','+00:00')).timestamp())
            kind=classify_ip(ip)
            return {'epoch':epoch,'timestamp':dt.datetime.fromtimestamp(epoch).astimezone().isoformat(timespec='seconds'),'source_ip':ip,'ip_type':kind,'username':user,'outcome':outcome,'source':'log import'}
    except Exception: pass
    m=FAIL_RE.search(line); outcome='failed'
    if not m:
        m=ACCEPT_RE.search(line); outcome='success'
    if not m:
        m=INVALID_RE.search(line); outcome='invalid_user'
    if not m:
        m=PAM_RE.search(line); outcome='failed'
    if not m:return None
    ip=m.group('ip'); user=(m.groupdict().get('user') or 'unknown').strip()
    kind=classify_ip(ip)
    epoch=local_epoch(line,fallback)
    return {'epoch':epoch,'timestamp':dt.datetime.fromtimestamp(epoch).astimezone().isoformat(timespec='seconds'), 'source_ip':ip,'ip_type':kind,'username':user,'outcome':outcome,'source':'log import'}

def analyze(events, window_seconds=300):
    now=max([e.get('epoch',0) for e in events] or [dt.datetime.now().timestamp()]); profiles={}; failures=sum(e['outcome']!='success' for e in events); successes=sum(e['outcome']=='success' for e in events)
    for e in events:
        p=profiles.setdefault(e['source_ip'],{'ip':e['source_ip'],'ip_type':e.get('ip_type','unknown'),'attempts':0,'failed':0,'success':0,'users':set(),'first':e['epoch'],'last':e['epoch'],'times':[]})
        p['attempts']+=1;p['failed']+=e['outcome']!='success';p['success']+=e['outcome']=='success';p['users'].add(e['username']);p['first']=min(p['first'],e['epoch']);p['last']=max(p['last'],e['epoch']);p['times'].append(e['epoch'])
    for p in profiles.values():
        recent=sum(now-t<=window_seconds for t in p['times']); distinct=len(p['users']); score=min(100, recent*12+max(0,distinct-1)*10+(25 if p['failed']>=10 else 0)+(20 if p['failed'] and p['success'] else 0));p['distinct_users']=distinct;p['attempts_5m']=recent;p['risk_score']=score;p['severity']='critical' if score>=80 else 'high' if score>=55 else 'medium' if score>=25 else 'low';p['pattern']='username spraying' if recent>=5 and distinct>=4 else 'repeated brute-force' if recent>=5 else 'username probing' if distinct>=3 else 'low-volume activity';p['users']=sorted(p['users']);p['duration']=max(0,p['last']-p['first'])
    return {'total':len(events),'failed':failures,'successful':successes,'unique_ips':len(profiles),'profiles':sorted(profiles.values(),key=lambda p:(-p['risk_score'],-p['attempts'])),'events':events}

class LogAnalyzer:
    def __init__(self): self.events=[];self.seen=set()
    def add_line(self,line,source='live monitor'):
        e=parse_line(line)
        if not e:return None
        e['source']=source
        # Keep exact log line as a dedup key for journal stream replay/reconnect.
        key=(line.strip(),round(e['epoch']))
        if key in self.seen:return None
        self.seen.add(key);self.events.append(e);return e
    def add_vault_event(self,row):
        epoch=float(row.get('epoch') or 0)
        outcome='success' if row.get('outcome')=='success' or row.get('event')=='vault_unlock_success' else 'failed'
        event_id=str(row.get('id') or f"vault-{epoch}-{outcome}")
        key=('vault',event_id)
        if key in self.seen:return None
        local=dt.datetime.fromtimestamp(epoch).astimezone().isoformat(timespec='seconds')
        e={'id':event_id,'epoch':epoch,'timestamp':local,'source_ip':'LOCAL VAULT','ip_type':'local/vault','username':'(not applicable)','outcome':outcome,'event_type':'vault_unlock','source':'vault authentication'}
        self.seen.add(key);self.events.append(e);return e
    def import_text(self,text):
        added=[]
        for line in text.splitlines():
            e=parse_line(line)
            if e:
                e['source']='offline log import';self.events.append(e);added.append(e)
        return added
    def clear(self):self.events.clear();self.seen.clear()
